export class TmsRestaurantResultBusinessAndProfitSamePeriodReportOutputEntity {
    total_profit: number;
	total_profit_same_period: number;
	total_rate_profit_same_period: number;
}