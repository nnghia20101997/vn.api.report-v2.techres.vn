export class TmsRestaurantResultBusinessAndProfitReportOutputEntity {
    total_profit: number;
}