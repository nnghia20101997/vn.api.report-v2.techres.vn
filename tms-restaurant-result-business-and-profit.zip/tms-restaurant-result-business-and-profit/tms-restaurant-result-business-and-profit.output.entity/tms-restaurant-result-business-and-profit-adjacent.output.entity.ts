export class TmsRestaurantResultBusinessAndProfitAdjacentReportOutputEntity {
    total_profit: number;
	total_profit_adjacent: number;
	total_rate_profit_adjacent: number;
}